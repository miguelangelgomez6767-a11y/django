from empresa.empleado import Empleado


class desarrollador(Empleado):
    def calcular_bonificacion(self):
        return self.salario * 0.20
